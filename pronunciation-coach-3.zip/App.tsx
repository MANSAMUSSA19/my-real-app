
import React, { useState, useEffect, useCallback, useRef } from 'react';
import type { PronunciationFeedback } from './types';
import { generatePracticeText, getPronunciationFeedback, getAudioForText } from './services/geminiService';
import { useSpeechRecognition } from './hooks/useSpeechRecognition';
import Header from './components/Header';
import Loader from './components/Loader';
import SubscriptionModal from './components/SubscriptionModal';
import { MicIcon, SparklesIcon, BookOpenIcon, SpeakerIcon, StopCircleIcon } from './constants';
import { decode, decodeAudioData } from './utils/audioUtils';

const FREE_PLAN_LIMIT = 5;

const App: React.FC = () => {
  const [practiceText, setPracticeText] = useState<string>('');
  const [isLoadingText, setIsLoadingText] = useState<boolean>(true);
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [feedback, setFeedback] = useState<PronunciationFeedback | null>(null);
  const [error, setError] = useState<string | null>(null);
  
  const [playingAudio, setPlayingAudio] = useState<string | null>(null);
  const [loadingAudio, setLoadingAudio] = useState<string | null>(null);

  const [isPlayingFullText, setIsPlayingFullText] = useState<boolean>(false);
  const [isLoadingFullText, setIsLoadingFullText] = useState<boolean>(false);

  const [subscriptionPlan, setSubscriptionPlan] = useState<'free' | 'pro'>('free');
  const [sessionCount, setSessionCount] = useState(0);
  const [isSubscriptionModalOpen, setIsSubscriptionModalOpen] = useState(false);
  const [isCheckoutVisible, setIsCheckoutVisible] = useState(false);

  const audioContextRef = useRef<AudioContext | null>(null);
  const audioSourceRef = useRef<AudioBufferSourceNode | null>(null);

  const {
    startListening,
    isListening,
    transcript,
    interimTranscript,
    error: recognitionError,
    isSupported,
  } = useSpeechRecognition();

  useEffect(() => {
    // Load subscription status and session count from localStorage
    const savedPlan = localStorage.getItem('subscriptionPlan') as 'free' | 'pro' | null;
    if (savedPlan) {
      setSubscriptionPlan(savedPlan);
    }

    const today = new Date().toLocaleDateString();
    const lastUsedDate = localStorage.getItem('lastUsedDate');
    const savedCount = parseInt(localStorage.getItem('sessionCount') || '0', 10);

    if (lastUsedDate === today) {
      setSessionCount(savedCount);
    } else {
      // It's a new day, reset the counter
      localStorage.setItem('sessionCount', '0');
      localStorage.setItem('lastUsedDate', today);
      setSessionCount(0);
    }
  }, []);

  const handleFetchPracticeText = useCallback(async () => {
    setIsLoadingText(true);
    setError(null);
    setFeedback(null);
    setPracticeText('');
    try {
      const text = await generatePracticeText();
      setPracticeText(text);
    } catch (err) {
      setError('Failed to fetch practice text. Please check your API key and try again.');
      console.error(err);
    } finally {
      setIsLoadingText(false);
    }
  }, []);

  const handleStopAudio = useCallback(() => {
    if (audioSourceRef.current) {
      audioSourceRef.current.stop();
      audioSourceRef.current.disconnect();
      audioSourceRef.current = null;
    }
    setPlayingAudio(null);
    setIsPlayingFullText(false);
  }, []);

  useEffect(() => {
    handleFetchPracticeText();
    const initAudioContext = () => {
      if (!audioContextRef.current) {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      }
      document.removeEventListener('click', initAudioContext);
    };
    document.addEventListener('click', initAudioContext);
    
    return () => {
      document.removeEventListener('click', initAudioContext);
      handleStopAudio();
      audioContextRef.current?.close();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (transcript && !isListening && !isAnalyzing) {
      const analyze = async () => {
        setIsAnalyzing(true);
        setError(null);
        setFeedback(null);
        try {
          const result = await getPronunciationFeedback(practiceText, transcript);
          setFeedback(result);
        } catch (err) {
          setError('Failed to analyze pronunciation. The AI model might be busy. Please try again.');
          console.error(err);
        } finally {
          setIsAnalyzing(false);
          if (subscriptionPlan === 'free') {
            const newCount = sessionCount + 1;
            setSessionCount(newCount);
            localStorage.setItem('sessionCount', newCount.toString());
            localStorage.setItem('lastUsedDate', new Date().toLocaleDateString());
          }
        }
      };
      analyze();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [transcript, isListening, practiceText]);

  const handleStart = () => {
    if (subscriptionPlan === 'free' && sessionCount >= FREE_PLAN_LIMIT) {
      setIsSubscriptionModalOpen(true);
      return;
    }
    setError(null);
    setFeedback(null);
    handleStopAudio();
    startListening();
  };
  
  const handlePlayAudio = useCallback(async (text: string) => {
    if (playingAudio === text) {
      handleStopAudio();
      return;
    }
    handleStopAudio();

    if (!audioContextRef.current || audioContextRef.current.state === 'suspended') {
      await audioContextRef.current?.resume();
    }
    
    if (!audioContextRef.current) {
        setError("Audio context not available.");
        return;
    }

    setLoadingAudio(text);
    setError(null);

    try {
      const base64Audio = await getAudioForText(text);
      const audioBuffer = await decodeAudioData(decode(base64Audio), audioContextRef.current, 24000, 1);
      
      const source = audioContextRef.current.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(audioContextRef.current.destination);
      source.start();

      source.onended = () => {
        if (audioSourceRef.current === source) {
            handleStopAudio();
        }
      };

      audioSourceRef.current = source;
      setPlayingAudio(text);

    } catch (err) {
      setError("Failed to play audio. Please try again.");
      console.error(err);
    } finally {
      setLoadingAudio(null);
    }
  }, [playingAudio, handleStopAudio]);

  const handlePlayFullText = useCallback(async () => {
    handleStopAudio();

    if (!audioContextRef.current || audioContextRef.current.state === 'suspended') {
        await audioContextRef.current?.resume();
    }
    if (!audioContextRef.current) {
        setError("Audio context not available.");
        return;
    }

    setIsLoadingFullText(true);
    setError(null);

    try {
        const base64Audio = await getAudioForText(practiceText);
        const audioBuffer = await decodeAudioData(decode(base64Audio), audioContextRef.current, 24000, 1);
        
        const source = audioContextRef.current.createBufferSource();
        source.buffer = audioBuffer;
        source.connect(audioContextRef.current.destination);
        source.start();

        source.onended = () => {
          if (audioSourceRef.current === source) {
            handleStopAudio();
          }
        };

        audioSourceRef.current = source;
        setIsPlayingFullText(true);

    } catch (err) {
        setError("Failed to play lecture audio. Please try again.");
        console.error(err);
    } finally {
        setIsLoadingFullText(false);
    }
  }, [practiceText, handleStopAudio]);

  const handleShowCheckout = () => {
    setIsCheckoutVisible(true);
  };
  
  const handlePaymentSuccess = () => {
    setSubscriptionPlan('pro');
    localStorage.setItem('subscriptionPlan', 'pro');
    setIsSubscriptionModalOpen(false);
    setIsCheckoutVisible(false);
  };

  const handleCloseModal = () => {
    setIsSubscriptionModalOpen(false);
    setIsCheckoutVisible(false);
  };

  const highlightText = () => {
    if (!practiceText || !feedback || feedback.corrections.length === 0) {
      return <p className="text-xl md:text-2xl leading-relaxed">{practiceText}</p>;
    }
  
    const words = practiceText.split(/(\s+)/);
    const mispronouncedWords = new Set(feedback.corrections.map(c => c.mispronouncedWord.toLowerCase().replace(/[.,!?]/g, '')));
  
    return (
      <p className="text-xl md:text-2xl leading-relaxed">
        {words.map((word, index) => {
          const cleanWord = word.toLowerCase().replace(/[.,!?]/g, '');
          if (mispronouncedWords.has(cleanWord)) {
            return (
              <span key={index} className="bg-yellow-200 rounded px-1">{word}</span>
            );
          }
          return <span key={index}>{word}</span>;
        })}
      </p>
    );
  };

  const remainingSessions = FREE_PLAN_LIMIT - sessionCount;

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <Header 
        subscriptionPlan={subscriptionPlan}
        remainingSessions={remainingSessions}
      />
      <main className="flex-grow container mx-auto p-4 md:p-8 flex flex-col items-center">
        {!isSupported && (
          <div className="w-full max-w-4xl bg-red-100 border-l-4 border-red-500 text-red-700 p-4 rounded-md mb-6" role="alert">
            <p className="font-bold">Browser Not Supported</p>
            <p>The Speech Recognition API is not supported by your browser. Please try Chrome or Edge.</p>
          </div>
        )}

        <div className="w-full max-w-4xl bg-white rounded-2xl shadow-lg p-6 md:p-8 mb-8 border border-slate-200">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-2xl font-bold text-slate-700 flex items-center"><BookOpenIcon className="mr-2"/> Your Text to Read</h2>
            <div className="flex items-center space-x-2">
              <button
                onClick={isPlayingFullText ? handleStopAudio : handlePlayFullText}
                disabled={isLoadingText || isListening || isAnalyzing || loadingAudio !== null || !practiceText}
                className="px-4 py-2 flex items-center bg-slate-100 text-slate-700 font-semibold rounded-lg hover:bg-slate-200 transition-colors disabled:opacity-50 disabled:cursor-not-allowed text-sm"
                aria-label={isPlayingFullText ? 'Stop lecture' : 'Listen to text'}
              >
                {isLoadingFullText ? (
                  <Loader />
                ) : isPlayingFullText ? (
                  <StopCircleIcon className="mr-2 h-5 w-5 text-red-500" />
                ) : (
                  <SpeakerIcon className="mr-2 h-5 w-5 text-blue-500" />
                )}
                <span>{isPlayingFullText ? 'Stop' : 'Listen'}</span>
              </button>
              <button
                onClick={handleFetchPracticeText}
                disabled={isLoadingText || isListening || isAnalyzing || isPlayingFullText || isLoadingFullText}
                className="px-4 py-2 bg-slate-100 text-slate-700 font-semibold rounded-lg hover:bg-slate-200 transition-colors disabled:opacity-50 disabled:cursor-not-allowed text-sm"
              >
                New Text
              </button>
            </div>
          </div>
          <div className="bg-slate-100/70 p-6 rounded-lg min-h-[120px] flex items-center justify-center">
            {isLoadingText ? <Loader /> : highlightText()}
          </div>
          <div className="mt-6 text-center">
             <button
                onClick={handleStart}
                disabled={!isSupported || isLoadingText || isAnalyzing || isListening || !practiceText || isPlayingFullText || isLoadingFullText}
                className={`w-full md:w-auto inline-flex items-center justify-center px-8 py-4 font-bold rounded-full text-lg transition-all shadow-md ${
                  isListening 
                    ? 'bg-red-500 text-white animate-pulse cursor-not-allowed' 
                    : 'bg-blue-600 text-white hover:bg-blue-700 disabled:bg-slate-300 disabled:cursor-not-allowed'
                }`}
              >
                {isListening ? (
                  <>
                    <MicIcon className="mr-3" />
                    <span>Listening...</span>
                  </>
                ) : (
                  <>
                    <MicIcon className="mr-3"/>
                    <span>Start Practicing</span>
                  </>
                )}
              </button>
          </div>
          {(isListening || interimTranscript) && (
              <div className="mt-4 p-4 bg-gray-100 rounded-lg text-center">
                <p className="text-gray-500 italic">{interimTranscript || "Listening..."}</p>
              </div>
          )}
        </div>

        {isAnalyzing && (
            <div className="w-full max-w-4xl flex flex-col items-center justify-center p-8">
                <Loader />
                <p className="text-slate-600 mt-4 text-lg">AI is analyzing your pronunciation...</p>
            </div>
        )}
        
        {error && (
            <div className="w-full max-w-4xl bg-red-100 border border-red-200 text-red-800 p-4 rounded-lg text-center" role="alert">
                <p className="font-semibold">An Error Occurred</p>
                <p>{error}</p>
            </div>
        )}
        
        {recognitionError && (
            <div className="w-full max-w-4xl bg-yellow-100 border border-yellow-200 text-yellow-800 p-4 rounded-lg text-center" role="alert">
                <p className="font-semibold">Speech Recognition Error</p>
                <p>{recognitionError}</p>
            </div>
        )}
        
        {feedback && (
          <div className="w-full max-w-4xl bg-white rounded-2xl shadow-lg p-6 md:p-8 border border-slate-200 animate-fade-in">
            <h2 className="text-2xl font-bold text-slate-700 mb-4 flex items-center"><SparklesIcon className="mr-2"/> AI Feedback</h2>
            <div className="bg-blue-50 border-l-4 border-blue-500 text-blue-800 p-4 rounded-md mb-6">
                <p className="font-semibold">Overall Feedback</p>
                <p>{feedback.overallFeedback}</p>
            </div>

            {feedback.corrections.length > 0 ? (
              <div>
                <h3 className="text-xl font-semibold text-slate-600 mb-4">Areas for Improvement</h3>
                <ul className="space-y-4">
                  {feedback.corrections.map((item, index) => (
                    <li key={index} className="p-4 bg-slate-50 rounded-lg border border-slate-200 flex justify-between items-center">
                      <div>
                        <p className="font-bold text-lg text-slate-800">
                          Word: <span className="bg-yellow-200 rounded px-2 py-1">{item.mispronouncedWord}</span>
                        </p>
                        <p className="text-sm text-slate-500 mt-1">
                            You said something like: <span className="italic">"{item.yourPronunciation}"</span>
                        </p>
                        <p className="mt-2 text-green-700"><span className="font-semibold">Suggestion:</span> {item.correction}</p>
                      </div>
                      <button 
                        onClick={() => handlePlayAudio(item.mispronouncedWord)}
                        disabled={loadingAudio !== null && loadingAudio !== item.mispronouncedWord || isPlayingFullText || isLoadingFullText}
                        className="p-2 rounded-full hover:bg-slate-200 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                        aria-label={playingAudio === item.mispronouncedWord ? 'Stop audio' : 'Listen to correction'}
                      >
                        {loadingAudio === item.mispronouncedWord ? (
                           <Loader />
                        ) : playingAudio === item.mispronouncedWord ? (
                           <StopCircleIcon className="h-8 w-8 text-red-500" />
                        ) : (
                           <SpeakerIcon className="h-8 w-8 text-blue-500" />
                        )}
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
            ) : (
                <div className="text-center p-6 bg-green-50 rounded-lg border border-green-200">
                    <p className="text-lg font-semibold text-green-800">Excellent pronunciation! No corrections needed.</p>
                </div>
            )}
          </div>
        )}
      </main>
      <SubscriptionModal 
        isOpen={isSubscriptionModalOpen}
        onClose={handleCloseModal}
        onUpgradeClick={handleShowCheckout}
        isCheckoutVisible={isCheckoutVisible}
        onPaymentSuccess={handlePaymentSuccess}
      />
    </div>
  );
};

export default App;
