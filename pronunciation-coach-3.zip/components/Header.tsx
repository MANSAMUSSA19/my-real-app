
import React from 'react';
import { MicVocalIcon, StarIcon } from '../constants';

interface HeaderProps {
  subscriptionPlan: 'free' | 'pro';
  remainingSessions: number;
}

const Header: React.FC<HeaderProps> = ({ subscriptionPlan, remainingSessions }) => {
  return (
    <header className="bg-white shadow-sm sticky top-0 z-10 border-b border-slate-200">
      <div className="container mx-auto px-4 md:px-8 py-4 flex items-center justify-between">
        <div className="flex items-center">
            <MicVocalIcon />
            <h1 className="text-xl md:text-2xl font-bold text-slate-800">
            AI Pronunciation Coach
            </h1>
        </div>
        <div>
            {subscriptionPlan === 'pro' ? (
                <div className="flex items-center px-3 py-1 bg-yellow-100 text-yellow-800 rounded-full text-sm font-semibold">
                    <StarIcon className="w-4 h-4 mr-2 text-yellow-500" />
                    <span>Pro Plan</span>
                </div>
            ) : (
                <div className="text-sm font-medium text-slate-600">
                    <span className="font-bold text-blue-600">{remainingSessions > 0 ? remainingSessions : 0}</span> free sessions left today
                </div>
            )}
        </div>
      </div>
    </header>
  );
};

export default Header;
