
import React from 'react';
import { StarIcon, CheckIcon, PaypalIcon, CreditCardIcon } from '../constants';
import Loader from './Loader';

interface SubscriptionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUpgradeClick: () => void;
  isCheckoutVisible: boolean;
  onPaymentSuccess: () => void;
}

const PlanSelectionView: React.FC<{ onUpgradeClick: () => void; }> = ({ onUpgradeClick }) => (
    <>
        <div className="p-8 text-center">
            <h2 id="subscription-modal-title" className="text-3xl font-bold text-slate-800">Unlock Your Full Potential</h2>
            <p className="mt-2 text-slate-600 max-w-2xl mx-auto">
                You've reached your daily limit of free sessions. Upgrade to Pro to practice without limits and accelerate your learning.
            </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-px bg-slate-200 rounded-b-2xl overflow-hidden">
            <div className="bg-slate-50 p-8">
                <h3 className="text-xl font-semibold text-slate-700">Free Plan</h3>
                <p className="mt-2 text-slate-500">For casual practice</p>
                <div className="mt-6">
                    <p className="text-4xl font-bold text-slate-800">$0<span className="text-lg font-medium text-slate-500">/month</span></p>
                </div>
                <ul className="mt-6 space-y-3 text-slate-600">
                    <li className="flex items-center"><CheckIcon className="w-5 h-5 text-blue-500 mr-3 flex-shrink-0" /><span><span className="font-semibold">5</span> AI feedback sessions per day</span></li>
                    <li className="flex items-center"><CheckIcon className="w-5 h-5 text-blue-500 mr-3 flex-shrink-0" /><span>Listen to correct pronunciation</span></li>
                </ul>
            </div>
            <div className="bg-white p-8 border-t-4 border-blue-600">
                 <h3 className="text-xl font-semibold text-blue-600 flex items-center">Pro Plan <StarIcon className="w-5 h-5 ml-2 text-yellow-400" /></h3>
                <p className="mt-2 text-slate-500">For dedicated learners</p>
                <div className="mt-6">
                    <p className="text-4xl font-bold text-slate-800">$9.99<span className="text-lg font-medium text-slate-500">/month</span></p>
                </div>
                <ul className="mt-6 space-y-3 text-slate-600">
                    <li className="flex items-center"><CheckIcon className="w-5 h-5 text-blue-500 mr-3 flex-shrink-0" /><span><span className="font-semibold">Unlimited</span> AI feedback sessions</span></li>
                    <li className="flex items-center"><CheckIcon className="w-5 h-5 text-blue-500 mr-3 flex-shrink-0" /><span>Listen to correct pronunciation</span></li>
                     <li className="flex items-center"><CheckIcon className="w-5 h-5 text-blue-500 mr-3 flex-shrink-0" /><span>Priority access to new features</span></li>
                </ul>
                <button onClick={onUpgradeClick} className="mt-8 w-full bg-blue-600 text-white font-bold py-3 px-6 rounded-lg hover:bg-blue-700 transition-all shadow-md">Upgrade to Pro</button>
            </div>
        </div>
    </>
);


const CheckoutForm: React.FC<{ onPaymentSuccess: () => void }> = ({ onPaymentSuccess }) => {
    const [paymentMethod, setPaymentMethod] = React.useState('card');
    const [isProcessing, setIsProcessing] = React.useState(false);

    const handlePayment = (e: React.FormEvent) => {
        e.preventDefault();
        setIsProcessing(true);
        setTimeout(() => {
            setIsProcessing(false);
            onPaymentSuccess();
        }, 2000);
    };

    return (
        <div className="p-8">
            <h2 className="text-2xl font-bold text-slate-800 text-center mb-6">Secure Checkout</h2>
            <div className="bg-slate-100 rounded-lg p-4 mb-6 flex justify-between items-center">
                <span className="font-semibold text-slate-700">Pro Plan</span>
                <span className="font-bold text-xl text-slate-800">$9.99 / month</span>
            </div>

            <div className="mb-6">
                <div className="flex border-b border-slate-200">
                    <button onClick={() => setPaymentMethod('card')} className={`px-4 py-3 font-semibold text-sm transition-colors ${paymentMethod === 'card' ? 'border-b-2 border-blue-600 text-blue-600' : 'text-slate-500 hover:text-slate-700'}`}>
                        <CreditCardIcon className="inline-block mr-2 h-5 w-5" /> Credit / Debit Card
                    </button>
                    <button onClick={() => setPaymentMethod('paypal')} className={`px-4 py-3 font-semibold text-sm transition-colors ${paymentMethod === 'paypal' ? 'border-b-2 border-blue-600 text-blue-600' : 'text-slate-500 hover:text-slate-700'}`}>
                        <PaypalIcon className="inline-block mr-2 h-5 w-5 text-[#00457C]" /> PayPal
                    </button>
                     <button onClick={() => setPaymentMethod('gpay')} className={`px-4 py-3 font-semibold text-sm transition-colors ${paymentMethod === 'gpay' ? 'border-b-2 border-blue-600 text-blue-600' : 'text-slate-500 hover:text-slate-700'}`}>
                        <span className="font-bold">G</span> Pay
                    </button>
                </div>

                <form onSubmit={handlePayment} className="pt-6">
                    {paymentMethod === 'card' && (
                        <div className="space-y-4">
                            <input 
                                type="text"
                                inputMode="numeric"
                                autoComplete="cc-number"
                                placeholder="Card Number"
                                className="w-full px-3 py-2 bg-slate-800 text-white placeholder-slate-400 border border-slate-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                                pattern="[\d ]{13,19}"
                                maxLength={19}
                                title="Enter a valid card number"
                            />
                            <div className="flex space-x-4">
                                <input
                                    type="text"
                                    inputMode="numeric"
                                    autoComplete="cc-exp"
                                    placeholder="MM / YY"
                                    className="w-1/2 px-3 py-2 bg-slate-800 text-white placeholder-slate-400 border border-slate-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                                    pattern="\d\d\s*/\s*\d\d"
                                    maxLength={7}
                                    title="Enter date as MM / YY"
                                />
                                <input
                                    type="text"
                                    inputMode="numeric"
                                    autoComplete="cc-csc"
                                    placeholder="CVC"
                                    className="w-1/2 px-3 py-2 bg-slate-800 text-white placeholder-slate-400 border border-slate-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                                    pattern="\d{3,4}"
                                    maxLength={4}
                                    title="Enter the 3 or 4 digit CVC"
                                />
                            </div>
                        </div>
                    )}
                    {paymentMethod === 'paypal' && <p className="text-slate-600 text-center py-4">You will be redirected to PayPal to complete your purchase.</p>}
                    {paymentMethod === 'gpay' && <p className="text-slate-600 text-center py-4">Follow the instructions on the Google Pay pop-up to complete your purchase.</p>}
                    
                    <button type="submit" disabled={isProcessing} className="mt-8 w-full bg-blue-600 text-white font-bold py-3 px-6 rounded-lg hover:bg-blue-700 transition-all shadow-md flex items-center justify-center disabled:bg-blue-400 disabled:cursor-not-allowed">
                        {isProcessing ? <Loader /> : `Pay $9.99`}
                    </button>
                </form>
            </div>
            <p className="text-xs text-slate-400 text-center italic">
                This is a simulated transaction. Your card will not be charged.
            </p>
        </div>
    );
};

const SubscriptionModal: React.FC<SubscriptionModalProps> = ({ isOpen, onClose, onUpgradeClick, isCheckoutVisible, onPaymentSuccess }) => {
  if (!isOpen) return null;

  return (
    <div 
      className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 p-4 animate-fade-in"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-labelledby="subscription-modal-title"
    >
      <div 
        className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl mx-auto transform transition-all"
        onClick={(e) => e.stopPropagation()}
      >
        {isCheckoutVisible ? (
            <CheckoutForm onPaymentSuccess={onPaymentSuccess} />
        ) : (
            <PlanSelectionView onUpgradeClick={onUpgradeClick} />
        )}
      </div>
    </div>
  );
};

export default SubscriptionModal;
