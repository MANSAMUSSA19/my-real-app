
import { GoogleGenAI, Modality, Type } from "@google/genai";
import type { PronunciationFeedback } from '../types';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function generatePracticeText(): Promise<string> {
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: 'Generate a single, simple, and common English sentence for a non-native speaker to practice pronunciation. The sentence should be between 10 to 15 words long.',
        });
        const text = response.text?.trim();
        if (!text) {
            throw new Error("Received an empty response from the API.");
        }
        // Clean up potential markdown or quotes
        return text.replace(/["*]/g, '');
    } catch (error) {
        console.error("Error generating practice text:", error);
        throw new Error("Failed to communicate with the Gemini API.");
    }
}

export async function getPronunciationFeedback(originalText: string, userTranscription: string): Promise<PronunciationFeedback> {
    if (!userTranscription) {
        return {
            overallFeedback: "It seems I didn't hear anything. Please make sure your microphone is working and try speaking closer to it.",
            corrections: [],
        };
    }

    const prompt = `
        You are an expert American English pronunciation coach.
        A non-native speaker was given the following text to read:
        --- ORIGINAL TEXT ---
        ${originalText}
        --- END ORIGINAL TEXT ---

        Their spoken version was transcribed by a speech-to-text tool as:
        --- USER'S TRANSCRIPTION ---
        ${userTranscription}
        --- END USER'S TRANSCRIPTION ---

        Your task is to analyze the user's transcription against the original text and provide constructive feedback to help them improve.

        Please provide your feedback in a JSON object. The JSON object must conform to the following schema.
        1.  "overallFeedback": A brief, encouraging summary (1-2 sentences) of their performance.
        2.  "corrections": An array of objects, where each object details a specific pronunciation error. If there are no errors, provide an empty array. Each correction object should have:
            - "mispronouncedWord": The word from the original text that was likely mispronounced.
            - "yourPronunciation": The corresponding word(s) from the user's transcription that indicate the mispronunciation.
            - "correction": A clear and simple explanation of how to pronounce the word correctly. Use simple phonetic hints if helpful (e.g., "should sound like 'cat', not 'cot'").

        Analyze for common pronunciation errors like incorrect vowel sounds, dropped consonants, or confusing similar-sounding words. Be encouraging and focus on the most important errors. If the transcription is perfect, say so in the overall feedback.
    `;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: prompt,
            config: {
                thinkingConfig: { thinkingBudget: 0 },
                responseMimeType: 'application/json',
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        overallFeedback: { type: Type.STRING },
                        corrections: {
                            type: Type.ARRAY,
                            items: {
                                type: Type.OBJECT,
                                properties: {
                                    mispronouncedWord: { type: Type.STRING },
                                    yourPronunciation: { type: Type.STRING },
                                    correction: { type: Type.STRING },
                                },
                                required: ['mispronouncedWord', 'yourPronunciation', 'correction'],
                            },
                        },
                    },
                    required: ['overallFeedback', 'corrections'],
                },
            },
        });

        if (!response.text) {
            throw new Error("Received empty feedback from API.");
        }

        const feedback = JSON.parse(response.text) as PronunciationFeedback;
        return feedback;

    } catch (error) {
        console.error("Error getting pronunciation feedback:", error);
        throw new Error("Failed to get feedback from the Gemini API.");
    }
}


export async function getAudioForText(text: string): Promise<string> {
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash-preview-tts",
            contents: [{ parts: [{ text: `Pronounce the word: ${text}` }] }],
            config: {
                responseModalities: [Modality.AUDIO],
                speechConfig: {
                    voiceConfig: {
                        prebuiltVoiceConfig: { voiceName: 'Kore' },
                    },
                },
            },
        });
        const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
        if (!base64Audio) {
            throw new Error("No audio data received from API.");
        }
        return base64Audio;
    } catch (error) {
        console.error("Error generating audio:", error);
        throw new Error("Failed to generate audio from the Gemini API.");
    }
}
