
export interface Correction {
  mispronouncedWord: string;
  yourPronunciation: string;
  correction: string;
}

export interface PronunciationFeedback {
  overallFeedback: string;
  corrections: Correction[];
}
